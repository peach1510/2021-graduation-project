//
//  SettingModel.swift
//  YES_EYES
//
//  Created by mgpark on 2021/07/24.
//

import Foundation

struct SettingModel {
    var mainTitle: String = ""
//    var rightImageView: String?
}
