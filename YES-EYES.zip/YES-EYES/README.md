# YES-EYES

- iOS app/Swift
- Deep learning for product recognition/Tensorflow & Core ML
- Web crawling/Selenium
- Server & DB/Firebase
